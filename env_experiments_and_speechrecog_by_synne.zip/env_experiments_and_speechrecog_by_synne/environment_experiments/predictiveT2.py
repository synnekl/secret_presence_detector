# -*- coding: utf-8 -*-
"""
Created on Thu Aug 21 11:34:12 2025
@author: synnekl
Same model as before, but now with performance evaluation (MSE and MAE).
"""

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.preprocessing import StandardScaler

# Load and prepare data
df = pd.read_csv("example_sensor_data.csv", sep=",")  # Make sure this matches your logging file

# Create target column (next temp_lps_C)
df["next_temp"] = df["temp_lps_C"].shift(-1)
df = df.dropna()

# Input features and target
X = df[["pressure_hPa", "humidity_pct", "temp_lps_C"]].values
y = df["next_temp"].values

# Normalize features
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Time-aware split (70% train, 15% val, 15% test)
N = len(X)
train_end = int(N * 0.70)
val_end = int(N * 0.85)

X_train, y_train = X[:train_end], y[:train_end]
X_val, y_val = X[train_end:val_end], y[train_end:val_end]
X_test, y_test = X[val_end:], y[val_end:]

# Define the model
model = keras.Sequential([
    layers.Dense(8, activation="relu", input_shape=(3,)),
    layers.Dense(1)
])

model.compile(optimizer="adam", loss="mse", metrics=["mae"])

# Train the model
model.fit(X_train, y_train, validation_data=(X_val, y_val), epochs=30, batch_size=16, verbose=1)

# Evaluate on test set
loss, mae = model.evaluate(X_test, y_test, verbose=0)
y_pred = model.predict(X_test).flatten()

print("\nTest set performance:")
print(f"  MSE: {mean_squared_error(y_test, y_pred):.4f}")
print(f"  MAE: {mean_absolute_error(y_test, y_pred):.4f}")

# Export to TFLite
converter = tf.lite.TFLiteConverter.from_keras_model(model)
tflite_model = converter.convert()

with open("model.tflite", "wb") as f:
    f.write(tflite_model)
print("\nModel saved as model.tflite")
