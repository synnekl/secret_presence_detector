Hi! 
This is some of the code, models and data made by Synne Krekling Lien during the hackaton
of the course 02901. 


Folder: initial_speech_recog

This folder contains code for a keyword recognizer including the pre-processing of
the .wav files and then. The model is a CNN trained on a smaller dataset
(mini-speech-commands) than the final model and is only a subset of commands
and no background noise, but it does contain the new “secret” dataset. 

Both the code and dataset are included. The model is able to recognize the
“secret” audio snippets with high accuracy and served as one of the first
working prototypes before we moved on to an altered version of Google’s open
TensorFlow Lite Model Maker code. 


Folder: environment_experiments

The purpose of this folder was to test and employ a model to the Arduino using
the built-in environment sensors. This folder includes a .txt file with
micropython code for reading and storing temperature, pressure, and relative
humidity from two sensors connected to an Arduino. 

I didn’t reach the stage of saving the collected data directly to my laptop,
but instead I started to use a dummy dataset (example_sensor_data.csv) to begin
training a weather-prediction model in Python. The idea was to eventually deploy
this predictor onto the Arduino. 

In addition, I carried out some smaller experiments, such as flashing the
onboard LED above a certain temperature (not included in the files, but tested).
