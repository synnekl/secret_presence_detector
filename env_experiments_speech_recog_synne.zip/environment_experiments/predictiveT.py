# -*- coding: utf-8 -*-
"""
Created on Thu Aug 21 11:23:54 2025

@author: synnekl
"""

import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

# Load your logged data
df = pd.read_csv("example_sensor_data.csv")

# Features: pressure, humidity, current temperature
X = df[["pressure_hPa", "humidity_pct", "temp_lps_C"]]

# Target: next-step temperature
df["next_temp"] = df["temp_lps_C"].shift(-1)
y = df["next_temp"].dropna()
X = X.iloc[:-1]

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Fit simple regression
model = LinearRegression()
model.fit(X_train, y_train)

print("R^2:", model.score(X_test, y_test))
